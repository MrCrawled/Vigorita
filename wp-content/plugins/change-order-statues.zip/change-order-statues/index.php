<?php
/* La finalidad del Index.php vació es la de ocultar la estructura de carpetas. 
Si un usuario entra en la ruta de la carpeta del plugin se encontrará una página en blanco. 
Si se elimina aparecerá la estructura de carpetas exponiendo potenciales ataques.
*/