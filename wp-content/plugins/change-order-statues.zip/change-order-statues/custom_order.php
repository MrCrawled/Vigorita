<?php 

require_once plugin_dir_path(__FILE__).'/admin/add_order_status.php';

    /*
    Plugin Name: Changer order statues
    Description: El plugin agrega cambia el estado de la orden automáticamente de on hold a finalized o completed
    Author: Folder I.T.
    Version: 1.0
    Author URI: https://folderit.net
    */


    defined('ABSPATH') or die("Adios");
?>